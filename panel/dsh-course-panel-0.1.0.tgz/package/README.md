# dsh-course-panel

深度学习课程问题池面板 —— DSH Profile Bundle。

## 这个包是什么

原先它是一个**动态 Cordis 插件**（`cordis_define` 创建）。动态插件只活在当前 DSH 进程的内存里，
**DSH 一重启就消失**，所以无法作为长期能力交付。这个包是它的**固化形态**：一个可安装的 Profile Bundle。

## 与动态版本的关键差异

| 项 | 动态插件 | 本包（固化） |
| --- | --- | --- |
| 存活范围 | 当前进程，重启即失 | 随 Profile 常驻 |
| 装载位置 | 进程内存 | `dsh.profile.bundles` |
| 客户端↔宿主 IPC | `harness.handle` / `host.call`（进程内） | **HTTP**：`/cip-api/<action>` + `fetch` |
| 客户端格式 | 动态求值 | `window.__ModuleLoader__.load({id, factory})` bundle |

> ⚠️ `harness` **不是任何包的导出**（已核实 `@deepseek-ai/dsh-scope` 不导出它），
> 它是动态沙箱注入的全局。因此正式插件不能用 `harness.handle`——
> 原来 15 个 handler 全部改写为 `/cip-api/*` HTTP 路由，客户端用同名 `host.call` shim 转发，
> 好处是所有调用点一个字都没改。

## 提供的路由

| 路由 | 用途 |
| --- | --- |
| `/cip-api/info` | 工作区状态、章列表、默认枚举 |
| `/cip-api/tree` | 课程脉络（5 模块 / 30 课时，含教案缺失标记） |
| `/cip-api/slides` | 课件页数据（`{chapter}` 选章） |
| `/cip-api/pool` | 问题池列表；带 `{path}` 则读单条 |
| `/cip-api/docs` | 材料列表；带 `{path}` 则读单份 |
| `/cip-api/ask` | 框选提问 → AI 作答 → 归档成问题条目 |
| `/cip-api/followup` | 带上下文的多轮追问 |
| `/cip-api/aianswer` | 重答首问 |
| `/cip-api/update` | 更新状态/字段/小节 |
| `/cip-api/submission.list` | 某课时的作业提交列表 |
| `/cip-api/submission.save` | 保存学生提交的代码 |
| `/cip-api/submission.read` | 读取某份提交 |
| `/cip-api/submission.grade` | 按教案批改（不给分数，只做证据初筛） |
| `/cip-media/<章>/<文件>` | 课件图片（每章独立目录，防同名覆盖） |
| `/cip-katex/katex.min.{js,css}` | 公式渲染（本机 node_modules，不依赖外网） |
| `/cip-panel.css` | 面板样式表（白名单搬运，便于热改） |

## 安装

```sh
dsh plugin --profile web add <本包路径或 tarball>
# 然后重启该 Profile
```

## 配置

工作区路径默认取环境变量 `CIP_WORKSPACE`，未设置时用内置默认值。
换机器部署时**必须**改这里（见 `src/index.js` 顶部 `WORKSPACE`）。

## 已知限制

- **课件章节名写死在 `CHAPTERS`**（第一/二/三章）。新增章节需改代码并重装。
- **`/cip-api/*` 无鉴权**。本包假定它只绑在本机回环或受信的隧道后面。
  不要把它直接暴露到公网——面板能读写你的课程工作区。
- 状态词表用「转教案修订」（与 `课程问题池/README.md` 的权威定义一致）。

## 目录

```
course-panel-plugin/
├─ package.json          声明 dsh.bundle.patch 与 dsh.client
├─ cordis.patch.yml      装载行：- insert: [{ id: course-panel, name: dsh-course-panel }]
├─ src/index.js          宿主半区（HTTP 路由 + 业务逻辑）
└─ lib/client.js         客户端半区（ModuleLoader bundle）
```
